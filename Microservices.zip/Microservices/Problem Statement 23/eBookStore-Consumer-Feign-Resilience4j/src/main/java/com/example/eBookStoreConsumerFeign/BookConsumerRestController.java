package com.example.eBookStoreConsumerFeign;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Scope("request")
public class BookConsumerRestController {
	@Autowired
	private BookServiceProxy bookserviceproxy;

	@GetMapping("/get-books/{id}")
	public Book getBookById(@PathVariable("id") long id) {
		Book book = bookserviceproxy.getBookById(id);
		return book;
	}
	
	@GetMapping("/get-books")
	public List<Book> getAllBooks() {
		List<Book> books = bookserviceproxy.getAllBooks();
		return books;
	}
}
