package com.example.eBookStoreConsumerFeign;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "book-service")
public interface BookServiceProxy {
	@Retry(name ="book-service")
	@CircuitBreaker(name ="book-service", fallbackMethod="fallbackMethodGetBookById")
	@GetMapping(value = "/books/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Book getBookById(@PathVariable("id") Long id);
	
	@Retry(name ="book-service")
	@CircuitBreaker(name ="book-service", fallbackMethod="fallbackMethodGetAllBooks")
	@GetMapping(value = "/books", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Book> getAllBooks();
	
	
	public default Book fallbackMethodGetBookById(Long id, Throwable cause) {
		System.out.println("Exception raised with message :===>" + cause.getMessage());
		return new Book(id, "F-Res Title", "F-Res Author", "F-Res Publisher", 2027);
	}

	public default List<Book> fallbackMethodGetAllBooks(Throwable cause) {
		System.out.println("Exception raised with message :===>" + cause.getMessage());
		return new ArrayList<Book>();
	}
}