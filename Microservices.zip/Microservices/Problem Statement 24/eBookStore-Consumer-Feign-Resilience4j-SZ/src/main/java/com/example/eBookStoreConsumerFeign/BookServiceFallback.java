package com.example.eBookStoreConsumerFeign;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class BookServiceFallback implements BookServiceProxy {

	@Override
	public Book getBookById(Long id) {
		return new Book(id, "F-Res Title", "F-Res Author", "F-Res Publisher", 0);
	}

	@Override
	public List<Book> getAllBooks() {
		return new ArrayList<Book>();
	}
}
