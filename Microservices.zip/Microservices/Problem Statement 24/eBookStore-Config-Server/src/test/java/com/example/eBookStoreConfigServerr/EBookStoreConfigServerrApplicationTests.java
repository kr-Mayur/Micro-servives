package com.example.eBookStoreConfigServerr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConfigServerrApplicationTests {

	@Test
	void contextLoads() {
	}

}
