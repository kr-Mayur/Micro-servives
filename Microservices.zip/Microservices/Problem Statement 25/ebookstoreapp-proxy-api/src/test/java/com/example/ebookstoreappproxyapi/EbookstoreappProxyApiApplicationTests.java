package com.example.ebookstoreappproxyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreappProxyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
