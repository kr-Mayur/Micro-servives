package com.example.eBookStoreConsumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.eBookStoreConsumer.Book;

@RestController
@Scope("request")
public class BookConsumerRestController {
    @Autowired
	private BookService bookservice;
    
		@GetMapping("/get-books/{id}")
	    public Book getBookById(@PathVariable("id") long id) {
	        return bookservice.getBookById(id);
	    }
	}