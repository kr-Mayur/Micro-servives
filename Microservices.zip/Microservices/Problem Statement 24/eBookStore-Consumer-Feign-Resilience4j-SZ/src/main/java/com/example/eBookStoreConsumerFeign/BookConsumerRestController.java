package com.example.eBookStoreConsumerFeign;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.eBookStoreConsumerFeign.BookConsumerRestController;


@RestController
@Scope("request")
public class BookConsumerRestController {
	@Autowired
	private BookServiceProxy bookserviceproxy;
	private Logger log = LoggerFactory.getLogger(BookConsumerRestController.class);
	

	@GetMapping("/get-books/{id}")
	public Book getBookById(@PathVariable("id") long id) {
		log.debug("In getBookById with Id:"+ id);
		Book book = bookserviceproxy.getBookById(id);
		log.debug("In getBookById with return value Book:" + book);
		return book;
	}
	
	@GetMapping("/get-books")
	public List<Book> getAllBooks() {
		List<Book> books = bookserviceproxy.getAllBooks();
		log.debug("In getBookById with return value Books:" + books);
		return books;
	}
}
