package com.example.eBookStoreConsumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class BookService {
	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod="fallbackForGetBookById")
	public Book getBookById(long id) {
		Book book = restTemplate.getForObject("http://book-service/books/" + id, Book.class);
		return book;
	}
	
	public Book fallbackForGetBookById(long id) {
		return new Book(id,"New Title","New Author","New Publisher",0);
	}
}

/*public Book(String title, String author, String publisher, int year) {
    this.title = title;
    this.author = author;
    this.publisher = publisher;
    this.year = year;
}*/