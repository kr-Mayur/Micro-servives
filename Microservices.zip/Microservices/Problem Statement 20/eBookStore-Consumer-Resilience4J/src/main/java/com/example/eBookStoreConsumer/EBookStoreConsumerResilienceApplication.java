package com.example.eBookStoreConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBookStoreConsumerResilienceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumerResilienceApplication.class, args);
	}
}
